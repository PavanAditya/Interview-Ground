<template>
<div>
    <div v-if="transactions === 'empty'">
        <label>Bitcoin Address: </label>
        <input v-model="address" aria-placeholder="Enter bitcoin address" />
        <p>
            <button @click="getTransactions">Get Transactions</button>
        </p>
    </div>
    <div v-else-if="loading">Loading...</div>
    <div v-else-if="!loading && transactions">
        <div v-for="transaction in transactions" :key="transaction.txid">
            <h2>
                {{transaction.hash}}
            </h2>
            <p>Fee: {{transaction.fee}}</p>
            <p>Date: {{transaction.datetime}}</p>
            <div class="transations-div">
                <div class="tin" v-if="transaction.txins[0].addresses[0]">
                    <h3>Transactions In</h3>
                    <p v-for="txin in transaction.txins" :key="txin.txout">{{txin.addresses[0]}} - ${{txin.amount}}</p>
                </div>
                <div v-else> No Transactions In Found</div>
                <div class="tout" v-if="transaction.txouts[0].addresses[0]">
                    <h3>Transactions Out</h3>
                    <p v-for="txout in transaction.txouts" :key="txout.script.hex">{{txout.addresses[0]}} - ${{txout.amount}}</p>
                </div>
                <div v-else> No Transactions Out Found</div>
            </div>
        </div>
        <button @click="this.transactions = 'empty'">Get New Transactions</button>
    </div>
    <div v-else>
        No Transactions Found
    </div>
</div>
</template>

<script>
export default {

    name: 'Transactions',
    computed: {
        // getDate (datetime) {
        //     if (datetime) {
        //     return Date(datetime);
        //     } else {
        //         return '';
        //     }
        // }
    },
    data() {
        return {
            cardName: 'Transactions',
            transactions: 'empty',
            loading: false,
            address: ''
        }
    },
    methods: {
        async getTransactions() {
            this.loading = true;
            let res = await fetch(`http://localhost:4000/transactions/${this.address}`);
            let transactionResponse = await res.json();
            if (transactionResponse.status === 200) {
                this.loading = false;
                this.transactions = JSON.parse(transactionResponse.data.body).payload;
                console.log(this.transactions);
            } else {
                this.loading = false;
                this.transactions = null;
            }
        }
    },
    mounted() {
        this.transactions = 'empty';
    },
}
</script>

<style lang="scss">
// .transations-div {
//     width: 100%;
//     .tin {
//         width: 50%;
//     }
//     .tout {
//         width: 50%;
//     }
// }
</style>
