<template>
  <!-- <img alt="Vue logo" src="./assets/logo.png">
  <HelloWorld msg="Welcome to Your Vue.js App"/> -->
  <Transactions />
</template>

<script>
// import HelloWorld from './components/HelloWorld.vue'
import Transactions from './components/Transactions.vue'

export default {
  name: 'App',
  components: {
    // HelloWorld,
    Transactions
  }
}
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>
