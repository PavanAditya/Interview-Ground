# Bitcoin Transactions

A NodeJs Backend built for tracking the bitcoin transactions with the given bitcoidn address.

Environment Needed:
NodeJS (possible version) installed in the system.

Commands:
Installing Dependencies: `npm i`
Running the app: `npm run app`
Running and Watching the app: `npm run app:watch` (Includes Nodemon for watching over the changes done in the app)